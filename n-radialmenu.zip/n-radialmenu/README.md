# Modern Radial Menu
 
 Hiçbiryerde göremeyeceğiniz bir radialmenu Neva olarak Bunuda Free Veriyoruz Discorda Gelerek Başka Free Scriptlerimizdende yararlanabilirsiniz.

## Özellikler

- Modern ve sade tasarım
- Kolay config sistemi
- Smooth animasyonlar

## Kurulum

1. Scripti `resources` klasörüne atın / Veya Bir [] Klasörüne Koyabilirsiniz.
2. `server.cfg` dosyanıza `ensure n-radialmenu` ekleyin
3. Sunucuyu yeniden başlatın

## Kullanım

- Menüyü açmak için: **F1** (config'den değiştirilebilir)
- Menüyü kapatmak için: **ESC**

## Config Düzenleme

`config.lua` dosyasından kolayca yeni öğeler ekleyebilirsiniz

## Lisans

MIT License

## Discord

`https://discord.gg/hSn7qNCDXJ`

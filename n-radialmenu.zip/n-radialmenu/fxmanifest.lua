fx_version 'cerulean'
game 'gta5'

author 'Neva'
description 'Neva Radial Menu Script'
version '1.0.0'

ui_page 'html/index.html'

client_scripts {
    'config.lua',
    'client.lua'
}

files {
    'html/index.html',
    'html/style.css',
    'html/script.js'
}
